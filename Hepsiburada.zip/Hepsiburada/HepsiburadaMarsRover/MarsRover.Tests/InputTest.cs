using System;
using System.Collections.Generic;
using MarsRover.BusinessLayer;
using MarsRover.Model;
using Xunit;

namespace MarsRover.Tests
{
    public class InputTest
    {
        [Fact]
        public void Plateau_Expected_Values()
        {
            var input = "5 5";
            var location = InputHelper.PlateauInputToLocation(input);
            if (location != null)
            {
                Assert.True(true, input);
            }
            else
            {
                Assert.False(false, input);
            }
        }

        [Fact]
        public void Plateau_UnExpected_Value_1()
        {
            var input = "55";
            var location = InputHelper.PlateauInputToLocation(input);
        }

        [Fact]
        public void Plateau_UnExpected_Value_2()
        {
            var input = "5 N";
            var location = InputHelper.PlateauInputToLocation(input);
        }

        [Fact]
        public void Rover_Expected_Value()
        {
            var rover = InputHelper.RoverInputToRover("1 2 N");
        }

        [Fact]
        public void Rover_UnExpected_Value()
        {
            var rover = InputHelper.RoverInputToRover("1 2 L");
        }

        [Fact]
        public void Direction_Expected_Value()
        {
            var directions = InputHelper.DirectionInputToDirections("LMLMLMLMM");
        }

        [Fact]
        public void Direction_UnExpected_Value()
        {
            var directions = InputHelper.DirectionInputToDirections("VVVVM");
        }

        [Fact]
        public void ProcessWorker_Test_Values_1()
        {
            var plateauLocation = InputHelper.PlateauInputToLocation("5 5");

            var rover = InputHelper.RoverInputToRover("1 2 N");
            rover.Directions = InputHelper.DirectionInputToDirections("LMLMLMLMM");

            var rovers = new List<Rover>();
            rovers.Add(rover);

            var processWorker = new ProcessWorker();
            var outputResults = processWorker.Start(plateauLocation, rovers);
        }

        [Fact]
        public void ProcessWorker_Test_Values_2()
        {
            var plateauLocation = InputHelper.PlateauInputToLocation("5 5");

            var rover = InputHelper.RoverInputToRover("3 3 E");
            rover.Directions = InputHelper.DirectionInputToDirections("MMRMMRMRRM");

            var rovers = new List<Rover>();
            rovers.Add(rover);

            var processWorker = new ProcessWorker();
            var outputResults = processWorker.Start(plateauLocation, rovers);
        }
    }
}
