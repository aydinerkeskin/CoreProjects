﻿using System;
using System.Collections.Generic;
using MarsRover.BusinessLayer;
using MarsRover.Model;

namespace MarsRover
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.Write("Plato Sınırları [X Y]: ");
                var plateauBoundInput = Console.ReadLine();
                var plateauLocation = InputHelper.PlateauInputToLocation(plateauBoundInput);

                var roverList = new List<Rover>();

                var exitControl = false;
                while (!exitControl)
                {
                    try
                    {
                        Rover rover = null;
                        Console.Write("Rover Bilgileri [X Y Cardinal]: ");
                        var roverInfoInput = Console.ReadLine();
                        rover = InputHelper.RoverInputToRover(roverInfoInput);

                        Console.Write("Yön Bilgileri: ");
                        var directionInput = Console.ReadLine();
                        rover.Directions = InputHelper.DirectionInputToDirections(directionInput);

                        roverList.Add(rover);

                        Console.Write("Devam etmek istiyor musunuz? [Y/N]: ");
                        var answer = Console.ReadLine();
                        if (!string.IsNullOrEmpty(answer) && answer.ToUpper().Equals("N"))
                        {
                            exitControl = true;
                        }
                    }
                    catch (System.Exception ex)
                    {
                        exitControl = true;
                        Console.WriteLine("Ex, Message: {0}, InnerMessage: {1}", ex.Message, (ex.InnerException != null) ? ex.InnerException.Message : "");
                    }
                }


                if (roverList.Count > 0)
                {
                    var worker = new ProcessWorker();
                    var outputs = worker.Start(plateauLocation, roverList);

                    foreach (var output in outputs)
                    {
                        Console.WriteLine(string.Format("{0} {1} {2}", output.Location.X, output.Location.Y, OutputHelper.CardinalTypeToString(output.CardinalType)));
                    }
                }

            }
            catch (System.Exception ex)
            {
                Console.WriteLine("Ex, Message: {0}, InnerMessage: {1}", ex.Message, (ex.InnerException != null) ? ex.InnerException.Message : "");
            }

            Console.WriteLine("İşlem tamamlandı...");
            Console.ReadLine();
        }
    }
}
