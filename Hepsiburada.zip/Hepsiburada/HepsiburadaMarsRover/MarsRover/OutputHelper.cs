using MarsRover.Model;

namespace MarsRover
{
    public class OutputHelper
    {
        public static string CardinalTypeToString(CardinalType cardinalType)
        {
            switch (cardinalType)
            {
                case CardinalType.North:
                    return "N";
                case CardinalType.East:
                    return "E";
                case CardinalType.South:
                    return "S";
                case CardinalType.West:
                    return "W";
                default:
                    return "";
            }
        }
    }
}