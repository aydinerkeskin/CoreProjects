using MarsRover.Model;

namespace MarsRover.BusinessLayer
{
    public class MoveForward : IMoveBase
    {
        public Rover Execute(Rover rover)
        {
            var cardinalType = rover.Orientation;

            if (cardinalType == CardinalType.North)
            {
                rover.Location.Y += 1;
            }
            else if (cardinalType == CardinalType.South)
            {
                rover.Location.Y -= 1;
            }
            else if (cardinalType == CardinalType.East)
            {
                rover.Location.X += 1;
            }
            else if (cardinalType == CardinalType.West)
            {
                rover.Location.X -= 1;
            }

            return rover;
        }
    }
}