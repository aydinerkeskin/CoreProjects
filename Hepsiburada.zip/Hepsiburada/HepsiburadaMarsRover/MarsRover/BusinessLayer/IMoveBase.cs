using MarsRover.Model;

namespace MarsRover.BusinessLayer
{
    public interface IMoveBase
    {
        public Rover Execute(Rover rover);
    }
}