using MarsRover.Model;

namespace MarsRover.BusinessLayer
{
    public class MoveManager
    {
        private IMoveBase _movement;

        public void SetMovement(IMoveBase movement)
        {
            this._movement = movement;
        }

        public Rover Execute(Rover rover)
        {
            if (this._movement == null)
            {
                throw new System.Exception("Harekete başlamadan önce hareket şeklinin girildiğinden emin olun!");
            }
            return this._movement.Execute(rover);
        }
    }
}