using MarsRover.Model;

namespace MarsRover.BusinessLayer
{
    public class MoveLeft : IMoveBase
    {
        public Rover Execute(Rover rover)
        {
            rover.Orientation = rover.CurrentCardinal.LeftCardinal;
            return rover;
        }
    }
}