using System;
using System.Collections.Generic;
using System.Linq;
using MarsRover.Model;

namespace MarsRover.BusinessLayer
{
    public class ProcessWorker
    {
        public List<OutputResult> Start(Location plateauLocation, List<Rover> rovers)
        {
            var outputResults = new List<OutputResult>();

            for (int i = 0; i < rovers.Count; i++)
            {
                var outputResult = new OutputResult()
                {
                    Location = rovers[0].Location,
                    CardinalType = rovers[0].Orientation
                };

                var moveManager = new MoveManager();

                foreach (var direction in rovers[i].Directions)
                {
                    if (direction == DirectionType.Left)
                    {
                        moveManager.SetMovement(new MoveLeft());
                    }
                    else if (direction == DirectionType.Right)
                    {
                        moveManager.SetMovement(new MoveRight());
                    }
                    else if (direction == DirectionType.Move)
                    {
                        moveManager.SetMovement(new MoveForward());
                    }

                    var tmpRover = moveManager.Execute(rovers[i]);

                    if (EdgeControl(tmpRover.Location, plateauLocation))
                    {
                        rovers[i] = tmpRover;

                        outputResult.Location = tmpRover.Location;
                        outputResult.CardinalType = tmpRover.Orientation;
                    }
                    else
                    {
                        outputResult.Location = rovers[i].Location;
                        outputResult.CardinalType = rovers[i].Orientation;
                        break;
                    }
                }

                outputResults.Add(outputResult);
            }

            return outputResults;
        }

        private bool EdgeControl(Location nextLocation, Location plateauLocation)
        {
            if (nextLocation.X < 0 || nextLocation.X > plateauLocation.X ||
            nextLocation.Y < 0 || nextLocation.Y > plateauLocation.Y)
            {
                return false;
            }
            return true;
        }



    }
}