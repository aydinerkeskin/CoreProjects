using MarsRover.Model;

namespace MarsRover.BusinessLayer
{
    public class MoveRight : IMoveBase
    {
        public Rover Execute(Rover rover)
        {
            rover.Orientation = rover.CurrentCardinal.RightCardinal;
            return rover;
        }
    }
}