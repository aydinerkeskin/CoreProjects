using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using MarsRover.Model;

namespace MarsRover
{
    public class InputHelper
    {
        public static Location PlateauInputToLocation(string input)
        {
            Location location = null;
            try
            {
                var inputParts = input.Split(" ");
                var result = Regex.Match(input, "^[0-9] [0-9]*$");
                if (result.Success)
                {
                    var inputArray = input.Split();
                    location = new Location();
                    location.X = int.Parse(inputArray[0]);
                    location.Y = int.Parse(inputArray[1]);
                }
                else
                {
                    throw new System.Exception("Plato sınırı için X:[0-9] Y:[0-9] şeklinde giriş yapınız!");
                }
            }
            catch (System.Exception ex)
            {
                throw new System.Exception("Plato sınırı uygun giriş yapılmadı!", ex);
            }
            return location;
        }

        public static Rover RoverInputToRover(string input)
        {
            Rover rover = null;
            try
            {
                var inputParts = input.Split(" ");
                var regexPatterns = string.Format("^[0-9] [0-9] [{0}]*$", "NSWE");
                var result = Regex.Match(input, regexPatterns);
                if (result.Success)
                {
                    var inputArray = input.Split();
                    rover = new Rover();

                    rover.Location = new Location();
                    rover.Location.X = int.Parse(inputArray[0]);
                    rover.Location.Y = int.Parse(inputArray[1]);
                    rover.Orientation = ConvertToCardinalType(inputArray[2]);

                    if (ConvertToCardinalType(inputArray[2]) == CardinalType.Invalid)
                    {
                        throw new System.Exception("Girilen orientation değeri geçersiz!");
                    }
                }
                else
                {
                    throw new System.Exception("Rover için X:[0-9] Y:[0-9] Orientation şeklinde giriş yapınız!");
                }
            }
            catch (System.Exception ex)
            {
                throw new System.Exception("Rover için uygun giriş yapılmadı!", ex);
            }
            return rover;
        }

        public static List<DirectionType> DirectionInputToDirections(string input)
        {
            var directions = new List<DirectionType>();
            try
            {
                var result = Regex.Match(input, "[LRM]{0,50}");
                if (result.Success)
                {
                    var inputArray = input.ToCharArray();

                    for (int i = 0; i < inputArray.Length; i++)
                    {
                        var directionType = ConvertToDirectionType(inputArray[i]);
                        if (directionType == DirectionType.Invalid)
                        {
                            throw new System.Exception(string.Format("Girilen {0} yön değeri geçersiz!", inputArray[i]));
                        }
                        else
                        {
                            directions.Add(directionType);
                        }
                    }
                }
                else
                {
                    throw new System.Exception("Rover için X:[0-9] Y:[0-9] Orientation şeklinde giriş yapınız!");
                }
            }
            catch (System.Exception ex)
            {
                throw new System.Exception("Rover için uygun giriş yapılmadı!", ex);
            }
            return directions;
        }

        private static CardinalType ConvertToCardinalType(string value)
        {
            switch (value)
            {
                case "N":
                    return CardinalType.North;
                case "E":
                    return CardinalType.East;
                case "S":
                    return CardinalType.South;
                case "W":
                    return CardinalType.West;
                default:
                    return CardinalType.Invalid;
            }
        }

        private static DirectionType ConvertToDirectionType(char value)
        {
            switch (value)
            {
                case 'L':
                    return DirectionType.Left;
                case 'R':
                    return DirectionType.Right;
                case 'M':
                    return DirectionType.Move;
                default:
                    return DirectionType.Invalid;
            }
        }
    }
}