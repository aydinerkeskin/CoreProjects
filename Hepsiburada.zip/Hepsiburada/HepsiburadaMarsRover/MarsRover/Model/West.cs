namespace MarsRover.Model
{
    public class West : ICardinal
    {
        public CardinalType Type
        {
            get
            {
                return CardinalType.West;
            }
        }
        public CardinalType LeftCardinal { get; set; } = CardinalType.South;
        public CardinalType RightCardinal { get; set; } = CardinalType.North;
    }
}