namespace MarsRover.Model
{
    public interface ICardinal
    {
        public CardinalType Type { get; }
        public CardinalType LeftCardinal { get; set; }
        public CardinalType RightCardinal { get; set; }
    }
}