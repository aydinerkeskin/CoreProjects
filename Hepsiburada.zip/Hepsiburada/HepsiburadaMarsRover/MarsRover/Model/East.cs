namespace MarsRover.Model
{
    public class East : ICardinal
    {
        public CardinalType Type
        {
            get
            {
                return CardinalType.East;
            }
        }
        public CardinalType LeftCardinal { get; set; } = CardinalType.North;
        public CardinalType RightCardinal { get; set; } = CardinalType.South;
    }
}