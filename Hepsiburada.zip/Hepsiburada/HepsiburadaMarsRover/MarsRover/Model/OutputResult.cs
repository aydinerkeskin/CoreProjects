namespace MarsRover.Model
{
    public class OutputResult
    {
        public Location Location { get; set; }
        public CardinalType CardinalType { get; set; }
    }
}