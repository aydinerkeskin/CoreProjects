using MarsRover.Model;

namespace MarsRover.Model
{
    public class CardinalGenerator
    {
        public static ICardinal Generate(CardinalType cardinalType)
        {
            if (cardinalType == CardinalType.North)
            {
                return new North();
            }
            else if (cardinalType == CardinalType.South)
            {
                return new South();
            }
            else if (cardinalType == CardinalType.West)
            {
                return new West();
            }
            else if (cardinalType == CardinalType.East)
            {
                return new East();
            }
            else
            {
                return null;
            }
        }
    }
}