using System.Collections.Generic;

namespace MarsRover.Model
{
    public class Rover
    {
        public Location Location { get; set; }

        private CardinalType _orientation;
        private ICardinal _cardinal;
        public CardinalType Orientation
        {
            get
            {
                return this._orientation;
            }
            set
            {
                this._orientation = value;
                this._cardinal = CardinalGenerator.Generate(value);
            }
        }
        public ICardinal CurrentCardinal
        {
            get
            {
                return this._cardinal;
            }
        }
        public List<DirectionType> Directions { get; set; }
    }
}