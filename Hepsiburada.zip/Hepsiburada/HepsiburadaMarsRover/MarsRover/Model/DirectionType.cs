namespace MarsRover.Model
{
    public enum DirectionType
    {
        Left,
        Right,
        Move,
        Invalid
    }
}