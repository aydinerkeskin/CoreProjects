namespace MarsRover.Model
{
    public class South : ICardinal
    {
        public CardinalType Type
        {
            get
            {
                return CardinalType.South;
            }
        }
        public CardinalType LeftCardinal { get; set; } = CardinalType.East;
        public CardinalType RightCardinal { get; set; } = CardinalType.West;
    }
}