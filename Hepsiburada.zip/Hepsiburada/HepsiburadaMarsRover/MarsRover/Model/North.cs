namespace MarsRover.Model
{
    public class North : ICardinal
    {
        public CardinalType Type
        {
            get
            {
                return CardinalType.North;
            }
        }
        public CardinalType LeftCardinal { get; set; } = CardinalType.West;
        public CardinalType RightCardinal { get; set; } = CardinalType.East;
    }
}