namespace MarsRover.Model
{
    public class Location
    {
        public int X { get; set; }
        public int Y { get; set; }
    }
}