namespace MarsRover.Model
{
    public enum CardinalType
    {
        North,
        East,
        South,
        West,
        Invalid
    }
}